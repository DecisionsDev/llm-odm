package com.ibm.rules.addemo;

public enum SkinColor {
	Ivory, Light, Medium, Dark, Ebony, Unknow
}
