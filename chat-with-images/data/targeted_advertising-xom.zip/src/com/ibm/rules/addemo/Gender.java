package com.ibm.rules.addemo;

public enum Gender {
	Male, Female, Unknow
}
