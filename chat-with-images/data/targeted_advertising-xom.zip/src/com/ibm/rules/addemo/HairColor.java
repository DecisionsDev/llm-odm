package com.ibm.rules.addemo;

public enum HairColor {
	Black, Brown, Blonde, Red, Gray, White, Unknow
}
