package com.ibm.rules.addemo;

public class CustomerElements {
	private SkinColor skinColor = SkinColor.Unknow;
	private HairColor hairColor = HairColor.Unknow;
	private Gender gender = Gender.Unknow;
	private int age = -1;

	public SkinColor getSkinColor() {
		return skinColor;
	}

	public void setSkinColor(SkinColor skinColor) {
		this.skinColor = skinColor;
	}

	public HairColor getHairColor() {
		return hairColor;
	}

	public void setHairColor(HairColor hairColor) {
		this.hairColor = hairColor;
	}

	public Gender getGender() {
		return gender;
	}

	public void setGender(Gender gender) {
		this.gender = gender;
	}

	public int getAge() {
		return age;
	}

	public void setAge(int age) {
		this.age = age;
	}
}
