package com.ibm.rules.addemo;

public enum AgeCategory {
	Infant, Children, Teens, Young, Adult, MiddleAged, Senior 
}
