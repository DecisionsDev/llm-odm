package com.ibm.rules.addemo;

public class BOMUtils {

	public static int GetNumber(String extractedNumber, DebugInfo debugInfo) {
		try {
			return Integer.valueOf(extractedNumber).intValue();
		} catch (Exception e) {
			debugInfo.addMessage(e.getLocalizedMessage());
			return -1;
		}
	}

	public static HairColor GetHairColor(String hair, DebugInfo debugInfo) {
		try {
			return HairColor.valueOf(hair);
		} catch (Exception e) {
			debugInfo.addMessage(e.getLocalizedMessage());
			return HairColor.Unknow;
		}
	}

	public static SkinColor GetSkinColor(String skin, DebugInfo debugInfo) {
		try {
			return SkinColor.valueOf(skin);
		} catch (Exception e) {
			debugInfo.addMessage(e.getLocalizedMessage());
			return SkinColor.Unknow;
		}
	}

	public static Gender getGender(String gender, DebugInfo debugInfo) {
		try {
			return Gender.valueOf(gender);
		} catch (Exception e) {
			debugInfo.addMessage(e.getLocalizedMessage());
			return Gender.Unknow;
		}
	}

}
