package com.ibm.rules.addemo;

import java.util.ArrayList;
import java.util.List;
import java.util.Set;
import java.util.TreeSet;

public class AdProposal {
	
	private List<String> tailoredProductNames = new ArrayList<String>();
	
	private Set<String> tailoredMessaging = new TreeSet<String>();
	
	private List<String> tailoredProducts = new ArrayList<String>();
	
	private List<String> tailoredChannels = new ArrayList<String>();
	
	private double discount;
	
	public void addTailoredMessage(String message) {
		tailoredMessaging.add(message);
	}
	
	public Set<String> getTailoredMessaging() {
		return tailoredMessaging;
	}

	public void setTailoredMessaging(Set<String> tailoredMessaging) {
		this.tailoredMessaging = tailoredMessaging;
	}
	
	public void addTailoredChannel(String channel) {
		tailoredChannels.add(channel);
	}
	
	public List<String> getTailoredChannels() {
		return tailoredChannels;
	}

	public void setTailoredChannels(List<String> tailoredChannels) {
		this.tailoredChannels = tailoredChannels;
	}
	
	public void addTailoredProduct(String product) {
		tailoredProducts.add(product);
	}

	public List<String> getTailoredProducts() {
		return tailoredProducts;
	}

	public void setTailoredProducts(List<String> tailoredProducts) {
		this.tailoredProducts = tailoredProducts;
	}

	public void addTailoredProductName(String product) {
		tailoredProductNames.add(product);
	}

	public List<String> getTailoredProductNames() {
		return tailoredProductNames;
	}

	public void setTailoredProductNames(List<String> tailoredProductNames) {
		this.tailoredProductNames = tailoredProductNames;
	}

	public double getDiscount() {
		return discount;
	}

	public void setDiscount(double discount) {
		this.discount = discount;
	}

}
